% This routine calculate the dissolution rate law

% Created on Nov 24th 2010
% Author: Valentina Prigiobbe
% -------------------------------------------------------------------------


function [D,r]=fDiss(typeDissLaw,Mineral,pH,mass0,T,x,kv,m2,SI,A,n,Ea)

if strcmp(typeDissLaw,'Linear')
    if strcmp(Mineral,'Olivine')
        A=0.0854;             %pre-exponential coefficient
        R=8.314472/1000;      %gas constant,  kJ K-1 mol-1
        Ea=52.9;              %activ. energy, kJ mol-1
        n=0.5;
        T=T+273.15;           % K
        B=log10(A*exp(-Ea/(R*T)));
        r=(10^(-n*pH+B));     % mol*cm-2*s-1
        PM=2*24.312+28.086+4*15.9994;               % g mol-1
        asp=900;              % cm2 g-1
        density=3.25;         % g cm-3
        gamma=asp*mass0./(3*density*m2*1e-8);
        D=gamma*r*PM/kv^(1/3)*1e-2;                      % m/s
    elseif strcmp(Mineral,'Metakaolin')
        % A=5.11e10;            % pre-exponential coefficient
        Ksp=10^(50.23);         % equilibrium constant
        R=8.314472/1000;        % gas constant,  kJ K-1 mol-1
        Kw=1e-14;
        Ea=85.96;               % activ. energy, kJ mol-1 from Izadifar et al. Nanomaterials 2023, 13, 1196. https://doi.org/10.3390/nano13071196
        % n=1;
        T=T+273.15;             % K
        k=4.45e-5;              % mol·m−2·s−1 from thesis
            k=k*1e-4;           % mol·cm−2·s−1 from thesis
        PM=222.1;               % g mol-1
        asp=140000;             % cm2 g-1
        density=2.6;%0.650;          % g cm-3 
        gamma=asp*mass0*PM/(3*kv^(2/3)*density*m2*1e-8); % cm3/g
        r=(Kw/10^(-pH)).^n*A*exp(-Ea/(R*T))*(1-10^(SI));  % mol*cm-2*s-1 !!!!!!!, *(1-10^(SI))
        D=r*gamma*1e-2;  % m/s
    end
end


end
