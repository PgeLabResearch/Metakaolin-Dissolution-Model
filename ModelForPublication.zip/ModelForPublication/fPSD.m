function f0 = fPSD(mu,sigma,A,x,type)


b(1)=mu;
b(2)=sigma;
b(3)=A;

if strcmp(type,'Lognorm')
    % The distribution is a standard lognormal distribution, Eq from LeBlanc and Fogler
     f0 = (x.^(-1)).*(b(3)*1/(b(2)*(2*pi)^0.5)*exp(-(log(x)-b(1)).^2/(2*b(2)^2)));
elseif strcmp(type,'Gauss')
    %% General model Gauss2:
    f0 = b(3)*1/(b(2)*(2*pi)^0.5)*exp(-(x-b(1)).^2/(2*b(2)^2));
elseif strcmp(type,'Ros')
    %% Rosin-Rammler2:
    f0=b(3)*(b(1)/b(2))*(x/b(2))^(b(1)-1)*exp(-(x/b(2))^b(1));
end
