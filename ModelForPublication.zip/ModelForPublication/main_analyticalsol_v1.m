% This is the analitical solution for the
% dissolution process.
% Author: Valentina Prigiobbe, 4/5/2024
% --------------------------------------

clear all
close all
clc

global type typePSD

% Loading data
% ------------
% Data with NaOH, the concetrations of Al are expressed as Al(OH)_4^- which
data=load('dataNaOH.txt'); % t (min); t (h); 2 M (mol/L); 4 M (mol/L); 6 M (mol/L); 8 M (mol/L); 2M (mmol/L);4M (mmol/L);6M (mmol/L);8M (mmol/L)'
exp=1;
if exp==1
    index=3;
    cNa=2; % m
    mass=0.0024;      % g
    A= 5e2*3.1;
    n=4;
    kv=1/80;               % Volume shape factor
elseif exp==2
    index=4;
    cNa=4; % m
    mass=0.0025;      % g
    A=5e1*4;
    n=4;
    kv=1/80;               % Volume shape factor
elseif exp==3
    index=5;
    cNa=6; % m
    mass=0.0027;      % g
    A=3.6e+1;
    n=4;
    kv=1/80;               % Volume shape factor
elseif exp==4
    index=6;
    cNa=8; % m
    mass=0.0028;      % g
    A=11;
    n=4;
    kv=1/60;               % Volume shape factor
end

% Physics
% -------
MWMetaK=222.1;         % g/mol
density=2.6;% 0.650;   % g/cm3 from https://www.keramost.cz/en/products/-/metakaolin
density=density*1e+6;  % g/m3
volumeparticles=mass/density; % m3
T =20;              % Celsius degree
Pco2 =1;            % bar
Q=1e-15;            % m3 s-1
V= 0.22/1000000;    % m3, volume of the solution

% Chemistry
% ---------
pH=7;
MWAlOH4=44.01;
cAl=data(1,index); % m
cSi=cAl; % m
[AlOH4,H2SiO42,H3SiO4,H4SiO4,Na_res,H_res,si_Meta_res,si_NASH1_res,si_NASH2_res,si_NASH3_res]=fPHREEQC_v1(cAl,cNa,cSi,T,Pco2);
pHnew=-log10(H_res);

% Setting figure
% --------------
fig=gcf;
set(gcf,'units','centimeters','position',[10,10,21.0,29.7/2])
[ha, pos] = tight_subplot(2, 2, [.08 .06],[.1 .07],[.07 .05]);

% PSD
% ---
typePSD='Lognorm';
mu=1.35;          % Mean value, micron
sigma=0.52;       % Standard deviation
Apsd=29.41;
[x0,PSD0,m00,m10,m20,m30]=fPSD_MOM(mu,sigma,Apsd,kv,typePSD); % measured in microm
massPSD=m30*1e-18*density; % g
scaleft=mass/massPSD;
Apsd=Apsd*scaleft;
[x0,PSD0,m00,m10,m20,m30]=fPSD_MOM(mu,sigma,Apsd,kv,typePSD); % measured in microm
axes(ha(2))
dim = [.9 .63 .3 .3];
str = '(b)';
annotation('textbox',dim,'String',str,'FitBoxToText','on','EdgeColor','none');
plot(x0,PSD0,'-k','LineWidth',1.5); hold on
xlabel('L, \mum')
ylabel('# of particles/m^3');
xticks([0:2:16]);
xlim([0 16]);
ax=gca;
ax.FontSize = 11;
ax.FontName="Times New Roman";
% title('Particle size distribution'),

% fig.Position(3:4)=[1000,400];
% Dissolution rate laws
% ---------------------
typeDissLaw='Linear';
Mineral='Metakaolin';
[D0,r0]=fDiss(typeDissLaw,Mineral,pHnew,mass,T,x0,kv,m20,si_Meta_res,A,n); % m/s

% PDE analytical solution
% -----------------------
i=1;
c(i)=cAl*1000; % mol/m3
t(i)=data(1,1)*60;
tend=t(i);
dt=(data(2,1)-data(1,1))*60;
L=x0;

while tend < 60*60
    L=L-data(i,1)*D0*1e+6*60;
    [x,PSD,m0,m1,m2(i),m3]=fPSD_MOM_evol(mu,sigma,Apsd,kv,typePSD,x0(1)+D0*1e+6,data(i,1)*60);
    axes(ha(2))
    plot(L,PSD,'--'); hold on
    f0 = fPSD(mu,sigma,Apsd,data(i,1)*60*D0*1e+6,typePSD); % dissolved particles
     i=i+1;
    c(i) = c(i-1)+((m2(i-1)*1e-12)*3*kv*D0*density)*dt/V.*(2/MWMetaK); % mol of Al/m3
    t(i)=data(i,1)*60; % s
    tend=t(i);    % s
    [AlOH4(i),H2SiO42(i),H3SiO4(i),H4SiO4(i),Na_res,H_res,si_Meta_res(i),si_NASH1_res(i),si_NASH2_res(i),si_NASH3_res(i)]=fPHREEQC_v1(c(i)./1000,cNa,c(i)./1000,T,Pco2);
    pHnew(i)=-log10(H_res);
    [D0,r0]=fDiss(typeDissLaw,Mineral,pHnew(i),mass,T,x0,kv,m20,si_Meta_res(i),A,n); % m/s
    D(i)=D0;
    r(i)=r0;
    clear PSD
    ylim([0 14e+5]);
end
F=(c./1000-(data(:,index))); % on aluminium

D_mean=mean(D) % m/s
r_mean=mean(r).*1e+4 % mol/m^2/s
r_vec=mean(r).*1e+4; % mol/m^2/s
pH_mean=mean(pHnew)


xticks([0:2:16]);
xlim([0 16]);

axes(ha(1))
dim = [.08 .63 .3 .3];
str = '(a)';
annotation('textbox',dim,'String',str,'FitBoxToText','on','EdgeColor','none');
plot(data(:,1),data(:,index),'o','LineWidth',1.5,'MarkerSize',8,'MarkerEdgeColor',[0.6350 0.0780 0.1840]), hold on
plot(t./60,c./1000,'-','LineWidth',1.5,'Color',[0.5 .5 .5]*0.01); hold on
leg=legend('Data','Model');
set(leg,'Box','off')
ax=gca;
ax.FontSize = 11;
ax.FontName="Times New Roman";
xlim([0 70]);
xticks([0:10:70]);
ylabel('c_{Al}, mol/kg')

if exp==3
    ylim([0 7e-3]);
    yticks([0:1e-3:7e-3]);
elseif exp==1 || exp==2
    ylim([0 5e-3]);
    yticks([0:1e-3:5e-3]);
elseif exp==4
    ylim([0 8e-3]);
    yticks([0:1e-3:8e-3]);

end

axes(ha(3))
dim = [.08 .17 .3 .3];
str = '(c)';
annotation('textbox',dim,'String',str,'FitBoxToText','on','EdgeColor','none');
plot(t./60,si_Meta_res,'-','LineWidth',1.5), hold on
plot(t./60,si_NASH1_res,'--r','LineWidth',1.5),
plot(t./60,si_NASH2_res,'-','LineWidth',1.5),
plot(t./60,si_NASH3_res,'-','LineWidth',1.5),
xlabel('time, min')
ylabel('SI')
ax=gca;
ax.FontSize = 11;
ax.FontName="Times New Roman";
leg=legend('Metakaolin','NASH1','NASH2','NASH3');
set(leg,'Box','off')

xlim([0 70]);
xticks([0:10:70]);
ylim([-11 0]);
% yticks([-11:-1:1]);
xlabel('time, min')

axes(ha(4))
dim = [.55 .17 .3 .3];
str = '(d)';
annotation('textbox',dim,'String',str,'FitBoxToText','on','EdgeColor','none');
ax=gca;
ax.FontSize = 11;
ax.FontName="Times New Roman";
plot(t./60,log10(AlOH4)','-','LineWidth',1.5), hold on
plot(t./60,log10(H3SiO4)','-','LineWidth',1.5,'Color',[0.4660 0.6740 0.1880]), hold on
plot(t./60,log10(H2SiO42)','--','LineWidth',1.5,'Color',[0.8500 0.3250 0.0980]), hold on
xlim([0 t(end)./60]);
xlabel('time, min')
ylabel('log_{10}c_i, mol/kg')
leg=legend('c_{Al(OH)_4^+}','c_{H_3SiO_4^{-}}','c_{H_2SiO_4^{2-}}','Orientation','horizontal');
set(leg,'Box','off')
ax=gca;
ax.FontSize = 11;
ax.FontName="Times New Roman";
ylim([-6 -2]);
xlabel('time, min')
xlim([0 70]);
xticks([0:10:70]);
xlabel('time, min')










