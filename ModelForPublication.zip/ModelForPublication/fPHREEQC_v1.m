% Linking phreeqc and matlab
% --------------------------

function [AlOH4,H2SiO42,H3SiO4,H4SiO4,Na_res,H_res,si_Meta_res,si_NASH1_res,si_NASH2_res,si_NASH3_res]=fPHREEQC_v1(cAl,cNa,cSi,T,Pco2)

% Creation of the ActiveX server:
iphreeqc = actxserver('IPhreeqcCOM.Object');

% Specify the database file according to the location on your file system.
% iphreeqc.LoadDatabase('C:\phreeqc\database\llnl.dat'); %Please change this line if you installed this somewhere else
%iphreeqc.LoadDatabase('C:\database\llnl.dat'); % Please change this line if you installed this somewhere else
% iphreeqc.LoadDatabase('C:\database\llnl.dat'); %Please change this line if you installed this somewhere else
% ================================================
% Call PhreeqC functionality using separate input file
% Note that in this way dynamic assignment of values to variables is not possible.
% I assume that the input file for PhreeqC is located in the current working directory.
% iphreeqc.RunFile([pwd,'\Nesquehonite_v1.pqi']);
% OUTphreeqFILE = iphreeqc.GetSelectedOutputArray

% ================================================
% Call PhreeqC functionality providing input as MATLAB multiline String

[OUTphreeqSTRING]=fgeochemistryMg_v1(cAl,cNa,cSi,T,Pco2);

AlOH4=OUTphreeqSTRING{2,10};
H2SiO42=OUTphreeqSTRING{2,11};
H3SiO4=OUTphreeqSTRING{2,12};
H4SiO4=OUTphreeqSTRING{2,13};
Na_res=OUTphreeqSTRING{2,14};
pH_res=OUTphreeqSTRING{2,7};
H_res=OUTphreeqSTRING{2,15};
si_Meta_res=OUTphreeqSTRING{2,16}; % metakaolin SI
si_NASH1_res=OUTphreeqSTRING{2,20}; % NASH SI, Na$_{0.92}$Al$_{0.92}$SiO$_{3.84}\cdot$ 0.54H$_{2}
si_NASH2_res=OUTphreeqSTRING{2,21}; % NASH SI, Na$_{0.5}$Al$_{0.5}$SiO$_{3}\cdot$ 0.354H$_{2}$O
si_NASH3_res=OUTphreeqSTRING{2,22}; % NASH SI Na$_{0.36}$Al$_{0.36}$SiO$_{2.72}\cdot$ 0.31H$_{2}$O





