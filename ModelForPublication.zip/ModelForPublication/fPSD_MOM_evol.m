% This routine derives: 
% > a PSD given:
    % - a mean value of grain diameter
    % - and a standard deviation
% > and the moments of the distribution

% Created on Nov 24th 2010. 
% updated 3/5/2024
% Author: Valentina Prigiobbe
% -------------------------------------------------------------------------

function [x,PSD,m0,m1,m2,m3]=fPSD_MOM_evol(mu,sigma,A,kv,type,D,t) 


if strcmp(type,'Lognorm')
    x=linspace(D*t,20,100);
    PSD=fPSD(mu,sigma,A,x,type);
    m0=quadl(@(x)fPSD(mu,sigma,A,x,type),x(1),x(end));
    m1=quadl(@(x)x.*fPSD(mu,sigma,A,x,type),x(1),x(end));
    m2=quadl(@(x)(x.^2).*fPSD(mu,sigma,A,x,type),x(1),x(end));
    m3=quadl(@(x)(x.^3).*fPSD(mu,sigma,A,x,type),x(1),x(end));
    PVD=PSD./(3*kv*x.^2);
elseif strcmp(type,'Gauss')
    x=linspace(mu-sigma*5,mu+sigma*5,500);
    PSD = normpdf(x,mu,sigma);
    m0=quadl(@(x)normpdf(x,mu,sigma),x(1),x(end));
    m1=quadl(@(x)x.*normpdf(x,mu,sigma),x(1),x(end));
    m2=quadl(@(x)(x.^2).*normpdf(x,mu,sigma),x(1),x(end));
    m3=quadl(@(x)(x.^3).*normpdf(x,mu,sigma),x(1),x(end));
    PVD=PSD./(3*kv*x.^2);
end
    v=kv*x.^3;
end

